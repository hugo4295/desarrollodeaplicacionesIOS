//
//  ViewController.swift
//  completoisbn
//
//  Created by Victor Hugo De la O Martínez on 04/07/16.
//  Copyright © 2016 Victor Hugo De la O Martínez. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    
    @IBOutlet weak var txtisbn: UITextField!
    @IBOutlet weak var lbltitulo: UILabel!
    @IBOutlet weak var lblautores: UILabel!
    @IBOutlet weak var lblportada: UILabel!
    @IBOutlet weak var lblerror: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtisbn.delegate = self;
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnbusca(sender: UIButton) {
        cargarinfo()
    }

    @IBAction func btnlimpia(sender: UIButton) {
        txtisbn.text = " "
        lblerror.text = " "
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        cargarinfo()
        return true;
    }
    
    func cargarinfo() {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:"
        let url = NSURL(string: urls + txtisbn.text!)
        do {
        let datos:NSData? = NSData(contentsOfURL: url!)
            if datos == nil {
               throw NSURLError.BadServerResponse
            }
        //let texto = NSString(data: datos!, encoding: NSUTF8StringEncoding)
            let json = try NSJSONSerialization.JSONObjectWithData(datos!, options: NSJSONReadingOptions.MutableLeaves)
            let dicgen = json as! NSDictionary
            let isbncompleto = "ISBN:" + txtisbn.text!
            let cuerpo = dicgen[isbncompleto] as! NSDictionary
            lbltitulo.text = cuerpo["title"] as! NSString as String
            let autores = cuerpo["authors"]	as! NSArray
            lblautores.text = " "
            for indice in 0..<autores.count {
                let autor = autores[indice] as! NSDictionary
                lblautores.text = lblautores.text! + (autor["name"] as! String) + "\n"
            }
            lblportada.text = " "
            let portadas = cuerpo["cover"] as! NSDictionary
            let portada = portadas["small"] as! NSString as String
            lblportada.text = portada
        }
        catch _ {
            lblerror.text = "error al conectar al servidor"
        }
        
        //print(texto!)
    }
    
    
}

