//
//  ViewController.swift
//  InfoISBN
//
//  Created by Victor Hugo De la O Martínez on 7/3/16.
//  Copyright © 2016 Victor Hugo De la O Martínez. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var txtisbn: UITextField!
    @IBOutlet weak var txtcontenido: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtisbn.delegate = self;
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnllama(sender: AnyObject) {
        cargarinfo()
    }
    
    @IBAction func btnlimpia(sender: AnyObject) {
        txtisbn.text = " "
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        cargarinfo()
        return true
    }
    
    func cargarinfo() {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:"
        let url = NSURL(string: urls + txtisbn.text!)
        do {
        let datos:NSData? = NSData(contentsOfURL: url!)
            if datos == nil {
                throw NSURLError.BadServerResponse
            }
        let texto = NSString(data: datos!, encoding: NSUTF8StringEncoding)
        print(texto!)
        txtcontenido.text = texto! as String
        } catch _ {
          txtcontenido.text = "error al conectar con el servidor"
        }
    }
    

}

